#!/bin/bash

gcc -std=gnu99 counter.c -o counter -lpthread
