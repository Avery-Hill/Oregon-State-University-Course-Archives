// TODO Complete the assignment following the instructions in the assignment
// document. Refer to the Concurrency lecture notes in Canvas for examples.
// You may also find slides 50 and 51 from Ben Brewster's Concurrency slide
// deck to be helpful (you can find Brewster's slide decks in Canvas -> files).

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

// Shared counter variable
int myCount = 0;

// Shared synchronization primitives
pthread_mutex_t myMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t myCond1 = PTHREAD_COND_INITIALIZER;
pthread_cond_t myCond2 = PTHREAD_COND_INITIALIZER;

// Flag indicating the consumer has printed the update
int consumerReady = 0;

// Consumer thread function
void* consumer_thread(void* arg) {
    int lastCount = 0;

    while (1) {
        pthread_mutex_lock(&myMutex);
        printf("CONSUMER: MUTEX LOCKED\n");

        while (myCount <= lastCount) {
            printf("CONSUMER: WAITING ON CONDITION VARIABLE 1\n");
            pthread_cond_wait(&myCond1, &myMutex);
        }

        // Print the update
        printf("Count updated: %d -> %d\n", lastCount, myCount);
        lastCount = myCount;

        // Signal producer that message is printed
        consumerReady = 1;
        printf("CONSUMER: SIGNALING CONDITION VARIABLE 2\n");
        pthread_cond_signal(&myCond2);

        printf("CONSUMER: MUTEX UNLOCKED\n");
        pthread_mutex_unlock(&myMutex);

        if (lastCount >= 10) {
            break;
        }
    }

    return NULL;
}

int main() {
    pthread_t consumer;

    // Start of program
    printf("PROGRAM START\n");

    // Create consumer thread
    pthread_create(&consumer, NULL, consumer_thread, NULL);
    printf("CONSUMER THREAD CREATED\n");

    while (myCount < 10) {
        pthread_mutex_lock(&myMutex);
        printf("PRODUCER: MUTEX LOCKED\n");

        // Increment count
        myCount++;
        printf("PRODUCER: SIGNALING CONDITION VARIABLE 1\n");
        pthread_cond_signal(&myCond1);

        // Wait for consumer to print update
        while (!consumerReady) {
            printf("PRODUCER: WAITING ON CONDITION VARIABLE 2\n");
            pthread_cond_wait(&myCond2, &myMutex);
        }
        consumerReady = 0;

        printf("PRODUCER: MUTEX UNLOCKED\n");
        pthread_mutex_unlock(&myMutex);
    }

    // Wait for consumer thread to finish
    pthread_join(consumer, NULL);

    // End of program
    printf("PROGRAM END\n");

    return 0;
}
