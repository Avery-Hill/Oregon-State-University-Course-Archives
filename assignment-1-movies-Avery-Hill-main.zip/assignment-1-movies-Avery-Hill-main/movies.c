#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Movie struct
struct movie {
    char* title;
    int year;
    char** languages;
    int numLanguages;
    double rating;
    struct movie* next;
};

// Function prototypes
struct movie* processFile(char* filePath, int* movieCount);
void showMoviesByYear(struct movie* list);
void showHighestRatedMovies(struct movie* list);
void showMoviesByLanguage(struct movie* list);
void freeMovies(struct movie* list);

char** parseLanguages(const char* languageStr, int* count);
void freeLanguages(char** languages, int count);

// Parse the languages string into an array of strings
char** parseLanguages(const char* languageStr, int* count) {
    char* langCopy = strdup(languageStr);
    char* langToken;
    int numLang = 0;
    int capacity = 10;
    char** languages = malloc(capacity * sizeof(char*));

    langCopy[strlen(langCopy) - 1] = '\0';
    langToken = langCopy + 1;

    char* token = strtok(langToken, ";");
    while (token != NULL) {
        if (numLang >= capacity) {
            capacity *= 2;
            languages = realloc(languages, capacity * sizeof(char*));
        }
        languages[numLang] = malloc(strlen(token) + 1);
        strcpy(languages[numLang], token);
        numLang++;
        token = strtok(NULL, ";");
    }

    *count = numLang;
    free(langCopy);
    return languages;
}

// Free languages array
void freeLanguages(char** languages, int count) {
    for (int i = 0; i < count; i++) {
        free(languages[i]);
    }
    free(languages);
}

// Process the CSV file line by line
struct movie* processFile(char* filePath, int* movieCount) {
    FILE* file = fopen(filePath, "r");
    if (!file) {
        printf("Could not open file %s\n", filePath);
        exit(1);
    }

    char line[1024];
    int firstLine = 1;
    struct movie* head = NULL;
    struct movie* tail = NULL;
    *movieCount = 0;

    while (fgets(line, sizeof(line), file)) {
        if (firstLine) {
            firstLine = 0;
            continue;
        }

        struct movie* newMovie = malloc(sizeof(struct movie));
        newMovie->next = NULL;

        // Parse Title
        char* ptr = strchr(line, ',');
        if (!ptr) continue;
        *ptr = '\0';
        newMovie->title = strdup(line);
        char* remaining = ptr + 1;

        // Parse Year
        ptr = strchr(remaining, ',');
        if (!ptr) { free(newMovie->title); free(newMovie); continue; }
        *ptr = '\0';
        newMovie->year = atoi(remaining);
        remaining = ptr + 1;

        // Parse Languages
        ptr = strchr(remaining, ',');
        if (!ptr) { free(newMovie->title); free(newMovie); continue; }
        *ptr = '\0';
        newMovie->languages = parseLanguages(remaining, &newMovie->numLanguages);
        remaining = ptr + 1;

        // Parse Rating
        remaining[strcspn(remaining, "\r\n")] = '\0';
        newMovie->rating = atof(remaining);

        // Add to linked list
        if (head == NULL) {
            head = newMovie;
            tail = newMovie;
        } else {
            tail->next = newMovie;
            tail = newMovie;
        }

        (*movieCount)++;
    }

    fclose(file);
    printf("Processed file %s and parsed data for %d movies\n", filePath, *movieCount);
    return head;
}

// Show movies released in a specific year
void showMoviesByYear(struct movie* list) {
    int year, found = 0;
    printf("Enter the year for which you want to see movies: ");
    scanf("%d", &year);

    while (list != NULL) {
        if (list->year == year) {
            printf("%s\n", list->title);
            found = 1;
        }
        list = list->next;
    }
    if (!found)
        printf("No data about movies released in the year %d\n", year);
}

// Show highest rated movie for each year
void showHighestRatedMovies(struct movie* list) {
    if (list == NULL) {
        printf("No movies loaded.\n");
        return;
    }

    struct movie* current = list;
    struct movie* bestMovies[150] = {0};

    while (current != NULL) {
        if (current->year < 1900 || current->year > 2049) {
            printf("Skipping invalid year: %d for movie %s\n", current->year, current->title);
            current = current->next;
            continue;
        }

        int idx = current->year - 1900;

        if (bestMovies[idx] == NULL || current->rating > bestMovies[idx]->rating) {
            bestMovies[idx] = current;
        }

        current = current->next;
    }

    for (int i = 0; i < 150; i++) {
        if (bestMovies[i] != NULL) {
            printf("%d %.1f %s\n", bestMovies[i]->year, bestMovies[i]->rating, bestMovies[i]->title);
        }
    }
}

// Show movies in a specific language
void showMoviesByLanguage(struct movie* list) {
    char language[20];
    int found = 0;

    printf("Enter the language for which you want to see movies: ");
    scanf("%s", language);

    while (list != NULL) {
        for (int i = 0; i < list->numLanguages; i++) {
            if (strcmp(list->languages[i], language) == 0) {
                printf("%d %s\n", list->year, list->title);
                found = 1;
            }
        }
        list = list->next;
    }
    if (!found)
        printf("No data about movies released in %s\n", language);
}

// Free the linked list and all allocated memory
void freeMovies(struct movie* list) {
    struct movie* temp;
    while (list != NULL) {
        temp = list;
        list = list->next;
        free(temp->title);
        freeLanguages(temp->languages, temp->numLanguages);
        free(temp);
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("You must provide the name of the file to process\n");
        return 1;
    }

    int movieCount;
    struct movie* movieList = processFile(argv[1], &movieCount);

    int choice;
    do {
        printf("\n1. Show movies released in the specified year\n");
        printf("2. Show highest rated movie for each year\n");
        printf("3. Show the title and year of release of all movies in a specific language\n");
        printf("4. Exit from the program\n\n");
        printf("Enter a choice from 1 to 4: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                showMoviesByYear(movieList);
                break;
            case 2:
                showHighestRatedMovies(movieList);
                break;
            case 3:
                showMoviesByLanguage(movieList);
                break;
            case 4:
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 4);

    freeMovies(movieList);
    return 0;
}
