#!/bin/bash

gcc -std=gnu99 movies.c -o movies
