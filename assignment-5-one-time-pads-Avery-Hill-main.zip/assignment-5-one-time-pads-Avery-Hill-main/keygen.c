#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // Ensure exactly one command-line argument is provided (key length)
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <keylength>\n", argv[0]);
        return 1;
    }

    // Convert the input string to an integer
    int len = atoi(argv[1]);
    if (len <= 0) {
        fprintf(stderr, "Invalid key length.\n");
        return 1;
    }

    // Seed the random number generator with current time
    srand((unsigned int)time(NULL));

    // Character set: uppercase letters A-Z and the space character (27 total)
    const char chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";

    // Generate and print 'len' random characters from the set
    int i;
    for (i = 0; i < len; i++) {
        putchar(chars[rand() % 27]);
    }

    // Add a newline at the end of the output
    putchar('\n');
    return 0;
}
