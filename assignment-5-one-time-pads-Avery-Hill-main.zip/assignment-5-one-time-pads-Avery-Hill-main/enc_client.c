#include <stdio.h>      // for input/output functions
#include <stdlib.h>     // for exit(), malloc(), etc.
#include <string.h>     // for string operations
#include <unistd.h>     // for close()
#include <netdb.h>      // for network-related structs and functions

#define MAX_LEN 1024    // maximum length for input buffers

// Reads a line from a file into the given buffer, stripping the newline
void read_file(char* filename, char* buffer) {
    FILE* fp = fopen(filename, "r");
    if (!fp) {
        perror("fopen"); // print error if file open fails
        exit(1);
    }
    fgets(buffer, MAX_LEN, fp); // read a line into the buffer
    buffer[strcspn(buffer, "\n")] = '\0'; // remove trailing newline
    fclose(fp);
}

// Validates that the input string contains only capital letters and spaces
void validate(const char* buffer) {
    int i;
    for (i = 0; buffer[i] != '\0'; i++) {
        if ((buffer[i] < 'A' || buffer[i] > 'Z') && buffer[i] != ' ') {
            fprintf(stderr, "enc_client error: input contains bad characters\n");
            exit(1); // exit if invalid character found
        }
    }
}

// Sends the entire buffer over the socket
void send_all(int sockfd, char* buffer) {
    int total = 0, len = strlen(buffer);
    while (total < len) {
        int sent = send(sockfd, buffer + total, len - total, 0);
        if (sent == -1) {
            perror("send");
            exit(1);
        }
        total += sent;
    }
}

// Receives data from the socket until the "@@" delimiter is found
void recv_until_delim(int sockfd, char* buffer) {
    int received = 0;
    while (strstr(buffer, "@@") == NULL) {
        int r = recv(sockfd, buffer + received, MAX_LEN - received, 0);
        if (r <= 0) {
            perror("recv");
            exit(1);
        }
        received += r;
    }
    buffer[strlen(buffer) - 2] = '\0'; // strip the "@@" delimiter
}

int main(int argc, char* argv[]) {
    // Ensure correct number of arguments
    if (argc != 4) {
        fprintf(stderr, "Usage: %s <plaintext> <key> <port>\n", argv[0]);
        exit(1);
    }

    // Buffers for plaintext, key, and full message to send
    char plaintext[MAX_LEN], key[MAX_LEN], message[2 * MAX_LEN + 4];

    // Read and validate input files
    read_file(argv[1], plaintext);
    read_file(argv[2], key);
    validate(plaintext);
    validate(key);

    // Ensure the key is at least as long as the plaintext
    if (strlen(key) < strlen(plaintext)) {
        fprintf(stderr, "Error: key '%s' is too short\n", argv[2]);
        exit(1);
    }

    // Construct the message with identifier 'E' followed by plaintext and key
    // Delimiters "@@" separate components and mark the end
    snprintf(message, sizeof(message), "E%s@@%s@@", plaintext, key);

    // Prepare to connect to server using address info
    struct addrinfo hints = {0}, *res, *p;
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    getaddrinfo("localhost", argv[3], &hints, &res);

    int sockfd = -1;
    // Try each result from getaddrinfo until a successful connection
    for (p = res; p != NULL; p = p->ai_next) {
        sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (sockfd == -1) continue;
        if (connect(sockfd, p->ai_addr, p->ai_addrlen) != -1) break; // success
        close(sockfd);
    }

    // Check if connection succeeded
    if (p == NULL) {
        fprintf(stderr, "Error: could not contact enc_server on port %s\n", argv[3]);
        exit(2);
    }
    freeaddrinfo(res); // clean up address info

    // Send the message to the server
    send_all(sockfd, message);

    // Receive the decrypted response from the server
    char response[MAX_LEN * 2] = {0};
    recv_until_delim(sockfd, response);
    printf("%s\n", response); // print the decrypted plaintext

    close(sockfd); // close the connection
    return 0;
}
