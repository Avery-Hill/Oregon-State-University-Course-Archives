#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <signal.h>

#define MAX_LEN 1024  // Maximum length for message and key buffers

// Signal handler to reap zombie processes created by fork
void handle_sigchld(int sig) {
    while (waitpid(-1, NULL, WNOHANG) > 0);
}

// Convert character to integer value: A-Z => 0-25, space => 26
int char_to_val(char c) { return c == ' ' ? 26 : c - 'A'; }

// Convert integer value back to character: 0-25 => A-Z, 26 => space
char val_to_char(int v) { return v == 26 ? ' ' : 'A' + v; }

// Perform one-time pad encryption on msg using key, result stored in out
void encrypt(char* msg, char* key, char* out) {
    int i;
    for (i = 0; msg[i] != '\0'; i++) {
        int m = char_to_val(msg[i]);
        int k = char_to_val(key[i]);
        out[i] = val_to_char((m + k) % 27);  // Modular addition to stay within valid character range
    }
    out[i] = '\0';  // Null-terminate result
}

// Handle one client connection
void handle_client(int sockfd) {
    char buffer[2 * MAX_LEN] = {0};

    // Receive entire message (format: "E<plaintext>@@<key>@@")
    recv(sockfd, buffer, sizeof(buffer), 0);
    
    // Ensure the message is meant for the encryption server
    if (buffer[0] != 'E') {
        close(sockfd);
        exit(2);
    }

    // Extract plaintext and key from message
    char* msg = strtok(buffer + 1, "@@");
    char* key = strtok(NULL, "@@");

    char result[MAX_LEN];
    encrypt(msg, key, result);  // Perform encryption
    strcat(result, "@@");       // Append delimiter to indicate end of message
    send(sockfd, result, strlen(result), 0);  // Send back encrypted message
    close(sockfd);
    exit(0);  // Child process exits after handling one client
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        exit(1);
    }

    // Create TCP socket
    int listen_fd = socket(AF_INET, SOCK_STREAM, 0);

    // Set up server address struct
    struct sockaddr_in server_addr = {0};
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(atoi(argv[1]));  // Use specified port
    server_addr.sin_addr.s_addr = INADDR_ANY;     // Accept connections on any IP

    // Bind socket to address and port
    bind(listen_fd, (struct sockaddr*)&server_addr, sizeof(server_addr));

    // Start listening for connections (up to 5 queued)
    listen(listen_fd, 5);

    // Set up signal handler to clean up child processes
    signal(SIGCHLD, handle_sigchld);

    // Server main loop: accept and handle client connections
    while (1) {
        struct sockaddr_in client_addr;
        socklen_t len = sizeof(client_addr);

        // Accept a client connection
        int conn_fd = accept(listen_fd, (struct sockaddr*)&client_addr, &len);

        // Fork a new process to handle the client
        if (fork() == 0) {
            close(listen_fd);        // Child doesn't need the listening socket
            handle_client(conn_fd);  // Handle the connection
        } else {
            close(conn_fd);          // Parent closes client socket and continues
        }
    }

    return 0;
}
