#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>
#include <sys/wait.h>

#define MAX_LEN 1024  // Maximum length for message/key buffers

// Signal handler to reap zombie child processes
void handle_sigchld(int sig) {
    while (waitpid(-1, NULL, WNOHANG) > 0);
}

// Converts a character (A-Z or space) to a numeric value (0–26)
int char_to_val(char c) {
    return (c == ' ') ? 26 : c - 'A';
}

// Converts a numeric value (0–26) back to a character (A-Z or space)
char val_to_char(int v) {
    return (v == 26) ? ' ' : 'A' + v;
}

// Decrypts a cipher text using the key and stores the result in 'result'
void decrypt(const char* cipher, const char* key, char* result) {
    int i;
    for (i = 0; cipher[i] != '\0'; i++) {
        int c = char_to_val(cipher[i]);              // Get numeric value of cipher char
        int k = char_to_val(key[i]);                 // Get numeric value of key char
        result[i] = val_to_char((c - k + 27) % 27);  // Perform modular subtraction and convert back
    }
    result[i] = '\0';          // Null-terminate the result
    strcat(result, "@@");      // Append '@@' end-of-message marker
}

// Handles communication with a single client
void handle_client(int connfd) {
    char id;

    // Receive client identifier; expect 'D' for decrypt client
    recv(connfd, &id, 1, 0);
    if (id != 'D') {
        send(connfd, "X", 1, 0);  // Send rejection signal
        close(connfd);
        exit(1);
    }
    send(connfd, "D", 1, 0);  // Acknowledge valid client

    // Receive data until the end-of-message marker '@@' is found
    char buffer[MAX_LEN * 2] = {0};
    int received = 0;
    while (strstr(buffer, "@@") == NULL) {
        int r = recv(connfd, buffer + received, sizeof(buffer) - received, 0);
        if (r <= 0) {
            perror("recv");
            exit(1);
        }
        received += r;
    }

    buffer[strlen(buffer) - 2] = '\0';  // Remove '@@' from the end

    // Split the buffer into message and key using '@@' delimiter
    char* msg = strtok(buffer + 1, "@@");
    char* key = strtok(NULL, "@@");

    // Validate inputs
    if (!msg || !key || strlen(key) < strlen(msg)) {
        fprintf(stderr, "Error: key too short or malformed input\n");
        close(connfd);
        exit(1);
    }

    // Perform decryption and send result back to client
    char plaintext[MAX_LEN * 2] = {0};
    decrypt(msg, key, plaintext);
    send(connfd, plaintext, strlen(plaintext), 0);

    close(connfd);  // Close connection
    exit(0);        // Exit child process
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        exit(1);
    }

    int port = atoi(argv[1]);  // Convert port argument to integer

    // Create socket
    int listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd < 0) {
        perror("socket");
        exit(1);
    }

    // Prepare the server address structure
    struct sockaddr_in server_addr = {0};
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket to the given port
    if (bind(listenfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind");
        exit(1);
    }

    listen(listenfd, 5);  // Listen for incoming connections, backlog = 5
    signal(SIGCHLD, handle_sigchld);  // Handle child process cleanup

    while (1) {
        struct sockaddr_in client_addr;
        socklen_t clilen = sizeof(client_addr);

        // Accept a new client connection
        int connfd = accept(listenfd, (struct sockaddr*)&client_addr, &clilen);
        if (connfd < 0) {
            perror("accept");
            continue;
        }

        // Fork a child process to handle the client
        pid_t pid = fork();
        if (pid == 0) {
            close(listenfd);         // Child doesn't need the listening socket
            handle_client(connfd);  // Handle client communication
        } else {
            close(connfd);          // Parent doesn't need the connected socket
        }
    }

    return 0;
}
