#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define MAX_LEN 1024

void read_file(const char* filename, char* buffer) {
    FILE* fp = fopen(filename, "r");
    if (!fp) {
        perror("Error opening file");
        exit(1);
    }
    fgets(buffer, MAX_LEN, fp);
    buffer[strcspn(buffer, "\n")] = '\0';
    fclose(fp);
}

void validate_input(const char* buffer) {
    int i;
    for (i = 0; buffer[i] != '\0'; i++) {
        if ((buffer[i] < 'A' || buffer[i] > 'Z') && buffer[i] != ' ') {
            fprintf(stderr, "dec_client error: input contains bad characters\n");
            exit(1);
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc != 4) {
        fprintf(stderr, "Usage: %s <ciphertext> <key> <port>\n", argv[0]);
        exit(1);
    }

    char ciphertext[MAX_LEN] = {0};
    char key[MAX_LEN] = {0};
    read_file(argv[1], ciphertext);
    read_file(argv[2], key);

    validate_input(ciphertext);
    validate_input(key);

    if (strlen(key) < strlen(ciphertext)) {
        fprintf(stderr, "Error: key '%s' is too short\n", argv[2]);
        exit(1);
    }

    struct addrinfo hints = {0}, *server_info = NULL;
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    int info_result = getaddrinfo("localhost", argv[3], &hints, &server_info);
    if (info_result != 0) {
        fprintf(stderr, "Error on getaddrinfo\n");
        exit(2);
    }

    int sockfd = -1;
    struct addrinfo* itr = server_info;
    while (itr != NULL && sockfd == -1) {
        sockfd = socket(itr->ai_family, itr->ai_socktype, itr->ai_protocol);
        if (sockfd == -1) {
            itr = itr->ai_next;
            continue;
        }
        if (connect(sockfd, itr->ai_addr, itr->ai_addrlen) == -1) {
            close(sockfd);
            sockfd = -1;
        }
        itr = itr->ai_next;
    }

    if (sockfd == -1) {
        fprintf(stderr, "Error: could not contact dec_server on port %s\n", argv[3]);
        freeaddrinfo(server_info);
        exit(2);
    }

    freeaddrinfo(server_info);

    // Identity handshake
    send(sockfd, "D", 1, 0);
    char id;
    recv(sockfd, &id, 1, 0);
    if (id != 'D') {
        fprintf(stderr, "dec_client: wrong server type\n");
        close(sockfd);
        exit(2);
    }

    // Compose message with @@ delimiter
    char message[2 * MAX_LEN + 4] = {0};
    snprintf(message, sizeof(message), "D%s@@%s@@", ciphertext, key);

    // Send full message
    int total_sent = 0;
    int message_len = strlen(message);
    while (total_sent < message_len) {
        int sent = send(sockfd, message + total_sent, message_len - total_sent, 0);
        if (sent == -1) {
            perror("send");
            close(sockfd);
            exit(1);
        }
        total_sent += sent;
    }

    // Receive until @@ seen
    char response[2 * MAX_LEN] = {0};
    int total_received = 0;
    while (strstr(response, "@@") == NULL) {
        int r = recv(sockfd, response + total_received, sizeof(response) - total_received - 1, 0);
        if (r <= 0) {
            perror("recv");
            close(sockfd);
            exit(1);
        }
        total_received += r;
    }
    response[strlen(response) - 2] = '\0'; // strip @@

    printf("%s\n", response);
    shutdown(sockfd, SHUT_RDWR);
    close(sockfd);

    return 0;
}
