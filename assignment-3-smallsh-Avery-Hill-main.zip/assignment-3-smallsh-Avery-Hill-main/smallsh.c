#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <stdbool.h>

#define MAX_CHARS 2048
#define MAX_ARGS 512

volatile sig_atomic_t foregroundOnlyMode = 0;
int lastStatus = 0;
pid_t bgPIDs[MAX_ARGS];
int bgCount = 0;

// Custom handler for SIGTSTP to toggle foreground-only mode
void handle_SIGTSTP(int signo) {
    if (foregroundOnlyMode == 0) {
        char* message = "\nEntering foreground-only mode (& is now ignored)\n";
        // Use write() instead of printf() inside signal handler (reentrant-safe)
        write(STDOUT_FILENO, message, 50);
        foregroundOnlyMode = 1;
    } else {
        char* message = "\nExiting foreground-only mode\n";
        write(STDOUT_FILENO, message, 30);
        foregroundOnlyMode = 0;
    }
}

// Expands all occurrences of "$$" with the PID of the shell process
void expand_pid(char* input, char* output) {
    char* ptr = input;
    char pidStr[20];
    sprintf(pidStr, "%d", getpid());

    while (*ptr) {
        if (*ptr == '$' && *(ptr + 1) == '$') {
            strcat(output, pidStr);
            ptr += 2;
        } else {
            strncat(output, ptr, 1);
            ptr++;
        }
    }
}

// Checks if any background child processes have completed
void check_bg_processes() {
    int childStatus;
    for (int i = 0; i < bgCount; i++) {
        // Use waitpid() with WNOHANG to non-blockingly check background children
        pid_t result = waitpid(bgPIDs[i], &childStatus, WNOHANG);
        if (result > 0) {
            if (WIFEXITED(childStatus)) {
                printf("background pid %d is done: exit value %d\n", result, WEXITSTATUS(childStatus));
            } else if (WIFSIGNALED(childStatus)) {
                printf("background pid %d is done: terminated by signal %d\n", result, WTERMSIG(childStatus));
            }
            fflush(stdout);
            // Remove completed PID from bgPIDs list
            for (int j = i; j < bgCount - 1; j++) {
                bgPIDs[j] = bgPIDs[j + 1];
            }
            bgCount--;
            i--;
        }
    }
}

int main() {
    struct sigaction SIGINT_action = {0}, SIGTSTP_action = {0};
    // Set shell to ignore SIGINT (Ctrl+C)
    SIGINT_action.sa_handler = SIG_IGN;
    sigaction(SIGINT, &SIGINT_action, NULL); // set custom SIGINT behavior

    // Set shell to handle SIGTSTP (Ctrl+Z) using our custom function
    SIGTSTP_action.sa_handler = handle_SIGTSTP;
    sigfillset(&SIGTSTP_action.sa_mask);
    SIGTSTP_action.sa_flags = SA_RESTART; // restart interrupted syscalls
    sigaction(SIGTSTP, &SIGTSTP_action, NULL); // set custom SIGTSTP behavior

    char* line = NULL;
    size_t bufferSize = 0;

    while (1) {
        check_bg_processes();
        printf(": ");
        fflush(stdout);

        ssize_t nread = getline(&line, &bufferSize, stdin);
        if (nread == -1) {
            clearerr(stdin);
            continue;
        }

        line[strcspn(line, "\n")] = '\0';
        if (line[0] == '\0' || line[0] == '#') continue;

        char expanded[MAX_CHARS] = "";
        expand_pid(line, expanded);

        char* args[MAX_ARGS];
        int argCount = 0;
        char* token = strtok(expanded, " ");
        char* inputFile = NULL;
        char* outputFile = NULL;
        bool background = false;

        while (token != NULL) {
            if (strcmp(token, "<") == 0) {
                token = strtok(NULL, " ");
                inputFile = token;
            } else if (strcmp(token, ">") == 0) {
                token = strtok(NULL, " ");
                outputFile = token;
            } else if (strcmp(token, "&") == 0 && strtok(NULL, " ") == NULL) {
                background = !foregroundOnlyMode;
                break;
            } else {
                args[argCount++] = token;
            }
            token = strtok(NULL, " ");
        }
        args[argCount] = NULL;

        if (args[0] == NULL) continue;

        // Built-in: exit
        if (strcmp(args[0], "exit") == 0) {
            // Kill any remaining background processes
            for (int i = 0; i < bgCount; i++) {
                kill(bgPIDs[i], SIGKILL); // kill() sends SIGKILL to bg processes
            }
            break;
        }
        // Built-in: cd
        else if (strcmp(args[0], "cd") == 0) {
            if (args[1]) chdir(args[1]); // chdir() changes directory
            else chdir(getenv("HOME")); // getenv() gets HOME env var
        }
        // Built-in: status
        else if (strcmp(args[0], "status") == 0) {
            printf("exit value %d\n", lastStatus);
            fflush(stdout);
        } else {
            // fork() creates a new child process
            pid_t spawnPid = fork();
            int childStatus;
            switch (spawnPid) {
                case -1:
                    perror("fork()");
                    exit(1);
                case 0:
                    // In child process
                    if (!background) {
                        SIGINT_action.sa_handler = SIG_DFL;
                        sigaction(SIGINT, &SIGINT_action, NULL); // restore SIGINT
                    }
                    SIGTSTP_action.sa_handler = SIG_IGN;
                    sigaction(SIGTSTP, &SIGTSTP_action, NULL); // ignore SIGTSTP

                    // Redirect input using open() and dup2()
                    if (inputFile) {
                        int inFD = open(inputFile, O_RDONLY); // open file for reading
                        if (inFD == -1) {
                            perror("cannot open input file");
                            exit(1);
                        }
                        dup2(inFD, 0); // dup2() sets stdin to inFD
                        close(inFD);
                    } else if (background) {
                        int devNull = open("/dev/null", O_RDONLY);
                        dup2(devNull, 0);
                    }

                    // Redirect output using open() and dup2()
                    if (outputFile) {
                        int outFD = open(outputFile, O_WRONLY | O_CREAT | O_TRUNC, 0644); // open for writing
                        if (outFD == -1) {
                            perror("cannot open output file");
                            exit(1);
                        }
                        dup2(outFD, 1); // dup2() sets stdout to outFD
                        close(outFD);
                    } else if (background) {
                        int devNull = open("/dev/null", O_WRONLY);
                        dup2(devNull, 1);
                    }

                    // execvp() replaces the child process with the requested command
                    execvp(args[0], args);
                    // If execvp() returns, it failed
                    perror(args[0]);
                    exit(1);
                default:
                    // In parent process
                    if (background) {
                        printf("background pid is %d\n", spawnPid);
                        fflush(stdout);
                        bgPIDs[bgCount++] = spawnPid;
                    } else {
                        // waitpid() blocks until foreground child terminates
                        waitpid(spawnPid, &childStatus, 0);
                        if (WIFEXITED(childStatus)) {
                            lastStatus = WEXITSTATUS(childStatus); // get exit code
                        } else if (WIFSIGNALED(childStatus)) {
                            int termSig = WTERMSIG(childStatus); // get termination signal
                            printf("terminated by signal %d\n", termSig);
                            fflush(stdout);
                            lastStatus = termSig;
                        }
                    }
            }
        }
    }
    free(line);
    return 0;
}
