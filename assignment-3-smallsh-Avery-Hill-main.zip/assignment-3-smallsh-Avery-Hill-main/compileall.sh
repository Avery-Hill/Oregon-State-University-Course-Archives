#!/bin/bash

gcc -std=gnu99 smallsh.c -o smallsh
