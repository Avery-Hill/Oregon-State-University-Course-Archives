/*
 * This file is where you should implement your binary search tree.  It already
 * contains skeletons of the functions you need to implement (along with
 * documentation for each function).  Feel free to implement any additional
 * functions you might need.  Also, don't forget to include your name and
 * @oregonstate.edu email address below.
 *
 * Name: Avery Hill
 * Email: hillav@oregonstate.edu
 */

#include <stdlib.h>

#include "bst.h"

/*
 * This structure represents a single node in a BST.  In addition to containing
 * pointers to its two child nodes (i.e. `left` and `right`), it contains two
 * fields representing the data stored at this node.  The `key` field is an
 * integer value that should be used as an identifier for the data in this
 * node.  Nodes in the BST should be ordered based on this `key` field.  The
 * `value` field stores data associated with the key.
 *
 * You should not modify this structure.
 */
struct bst_node {
  int key;
  void* value;
  struct bst_node* left;
  struct bst_node* right;
};


/*
 * This structure represents an entire BST.  It specifically contains a
 * reference to the root node of the tree.
 *
 * You should not modify this structure.
 */
struct bst {
  struct bst_node* root;
};

/*
 * This function should allocate and initialize a new, empty, BST and return
 * a pointer to it.
 */
struct bst* bst_create() {
    struct bst* new_bst = (struct bst*)malloc(sizeof(struct bst));
    if (new_bst) {
      new_bst->root = NULL;
    }
    return new_bst;
}

void bst_free_helper(struct bst_node* node) {
    if (node) {
      bst_free_helper(node->left);
      bst_free_helper(node->right);
      free(node);
    }
}
/*
 * This function should free the memory associated with a BST.  While this
 * function should up all memory used in the BST itself, it should not free
 * any memory allocated to the pointer values stored in the BST.  This is the
 * responsibility of the caller.
 *
 * Params:
 *   bst - the BST to be destroyed.  May not be NULL.
 */
void bst_free(struct bst* bst) {
    if (bst) {
      bst_free_helper(bst->root);
      free(bst);
    }
}

int bst_size_helper(struct bst_node* node) {
    if (node == NULL) {
      return 0;
    }
    return 1 + bst_size_helper(node->left) + bst_size_helper(node->right);
}

/*
 * This function should return the total number of elements stored in a given
 * BST.
 *
 * Params:
 *   bst - the BST whose elements are to be counted.  May not be NULL.
 */
int bst_size(struct bst* bst) {
    if (bst == NULL) {
      return 0;
    }
    return bst_size_helper(bst->root);
}

struct bst_node* bst_insert_helper(struct bst_node* node, int key, void* value) {
    if (node == NULL) {
      struct bst_node* new_node = (struct bst_node*)malloc(sizeof(struct bst_node));
      if (new_node) {
        new_node->key = key;
        new_node->value = value;
        new_node->left = NULL;
        new_node->right = NULL;
      }
      return new_node;
    }

    if (key < node->key) {
      node->left = bst_insert_helper(node->left, key, value);
    } else {
      node->right = bst_insert_helper(node->right, key, value);
    }

    return node;
}

/*
 * This function should insert a new key/value pair into the BST.  The key
 * should be used to order the key/value pair with respect to the other data
 * stored in the BST.  The value should be stored along with the key, once the
 * right location in the tree is found.
 *
 * Params:
 *   bst - the BST into which a new key/value pair is to be inserted.  May not
 *     be NULL.
 *   key - an integer value that should be used to order the key/value pair
 *     being inserted with respect to the other data in the BST.
 *   value - the value being inserted into the BST.  This should be stored in
 *     the BST alongside the key.  Note that this parameter has type void*,
 *     which means that a pointer of any type can be passed.
 */
void bst_insert(struct bst* bst, int key, void* value) {
    if (bst) {
      bst->root = bst_insert_helper(bst->root, key, value);
    }
}

struct bst_node* bst_find_min(struct bst_node* node) {
    while (node && node->left != NULL) {
      node = node->left;
    }
    return node;
}

struct bst_node* bst_remove_helper(struct bst_node* node, int key) {
    if (node == NULL) {
      return NULL;
    }

    if (key < node->key) {
      node->left = bst_remove_helper(node->left, key);
    } else if (key > node->key) {
      node->right = bst_remove_helper(node->right, key);
    } else {
      // Node found
      if (node->left == NULL) {
        struct bst_node* right_child = node->right;
        free(node);
        return right_child;
      } else if (node->right == NULL) {
        struct bst_node* left_child = node->left;
        free(node);
        return left_child;
      } else {
        // Node with two children: Find inorder successor
        struct bst_node* min_node = bst_find_min(node->right);
        node->key = min_node->key;
        node->value = min_node->value;
        node->right = bst_remove_helper(node->right, min_node->key);
      }
    }
    return node;
}

/*
 * This function should remove a key/value pair with a specified key from a
 * given BST.  If multiple values with the same key exist in the tree, this
 * function should remove the first one it encounters (i.e. the one closest to
 * the root of the tree).
 *
 * Params:
 *   bst - the BST from which a key/value pair is to be removed.  May not
 *     be NULL.
 *   key - the key of the key/value pair to be removed from the BST.
 */
void bst_remove(struct bst* bst, int key) {
    if (bst) {
      bst->root = bst_remove_helper(bst->root, key);
    }
}

void* bst_get_helper(struct bst_node* node, int key) {
    if (node == NULL) {
      return NULL;
    }
    if (key == node->key) {
      return node->value;
    } else if (key < node->key) {
      return bst_get_helper(node->left, key);
    } else {
      return bst_get_helper(node->right, key);
    }
}

/*
 * This function should return the value associated with a specified key in a
 * given BST.  If multiple values with the same key exist in the tree, this
 * function should return the first one it encounters (i.e. the one closest to
 * the root of the tree).  If the BST does not contain the specified key, this
 * function should return NULL.
 *
 * Params:
 *   bst - the BST from which a key/value pair is to be removed.  May not
 *     be NULL.
 *   key - the key of the key/value pair whose value is to be returned.
 *
 * Return:
 *   Should return the value associated with the key `key` in `bst` or NULL,
 *   if the key `key` was not found in `bst`.
 */
void* bst_get(struct bst* bst, int key) {
    if (bst == NULL) {
      return NULL;
    }
    return bst_get_helper(bst->root, key);
}

/*****************************************************************************
 **
 ** BST puzzle functions
 **
 *****************************************************************************/

int bst_height_helper(struct bst_node* node) {
    if (node == NULL) {
      return -1;  // Base case for an empty tree
    }
  
    int left_height = bst_height_helper(node->left);
    int right_height = bst_height_helper(node->right);

    // Height is the maximum depth between left and right subtrees, plus one
    return (left_height > right_height ? left_height : right_height) + 1;
}
/*
 * This function should return the height of a given BST, which is the maximum
 * depth of any node in the tree (i.e. the number of edges in the path from
 * the root to that node).  Note that the height of an empty tree is -1 by
 * convention.
 *
 * Params:
 *   bst - the BST whose height is to be computed
 *
 * Return:
 *   Should return the height of bst.
 */
 int bst_height(struct bst* bst) {
    if (bst == NULL) {
      return -1;
    }
    return bst_height_helper(bst->root);
 }

 int bst_path_sum_helper(struct bst_node* node, int remaining_sum) {
    if (node == NULL) {
      return 0;
    }

    remaining_sum -= node->key;

    // Check if we are at a leaf node and if the remaining sum is zero
    if (node->left == NULL && node->right == NULL && remaining_sum == 0) {
      return 1;
    }

    // Recursively check the left and right subtrees
    return bst_path_sum_helper(node->left, remaining_sum) ||
          bst_path_sum_helper(node->right, remaining_sum);
}

/*
 * This function should determine whether a specified value is a valid path
 * sum within a given BST.  In other words, this function should check whether
 * the given BST contains any path from the root to a leaf in which the keys
 * sum to the specified value.
 *
 * Params:
 *   bst - the BST whose paths sums to search
 *   sum - the value to search for among the path sums of `bst`
 *
 * Return:
 *   Should return 1 if `bst` contains any path from the root to a leaf in
 *   which the keys add up to `sum`.  Should return 0 otherwise.
 */
int bst_path_sum(struct bst* bst, int sum) {
    if (bst == NULL) {
      return 0;
    }
    return bst_path_sum_helper(bst->root, sum);
}

int bst_range_sum_helper(struct bst_node* node, int lower, int upper) {
    if (node == NULL) {
      return 0;
    }

    int sum = 0;

    // If the current node's key is within range, include it in the sum
    if (node->key >= lower && node->key <= upper) {
      sum += node->key;
    }

    // If the current node's key is greater than the lower bound,
    // explore the left subtree (potentially more keys in range)
    if (node->key > lower) {
      sum += bst_range_sum_helper(node->left, lower, upper);
    }

    // If the current node's key is less than the upper bound,
    // explore the right subtree (potentially more keys in range)
    if (node->key < upper) {
      sum += bst_range_sum_helper(node->right, lower, upper);
    }

    return sum;
}

/*
 * This function should compute a range sum in a given BST.  Specifically, it
 * should compute the sum of all keys in the BST between a given lower bound
 * and a given upper bound.  For full credit, you should not process any subtree
 * whose keys cannot be included in the range sum.
 *
 * Params:
 *   bst - the BST within which to compute a range sum
 *   lower - the lower bound of the range over which to compute a sum; this
 *     should be considered an *inclusive* bound; in other words a key that's
 *     equal to this bound should be included in the sum
 *   upper - the upper bound of the range over which to compute a sum; this
 *     should be considered an *inclusive* bound; in other words a key that's
 *     equal to this bound should be included in the sum
 *
 * Return:
 *   Should return the sum of all keys in `bst` between `lower` and `upper`.
 */
int bst_range_sum(struct bst* bst, int lower, int upper) {
    if (bst == NULL) {
      return 0;
    }
    return bst_range_sum_helper(bst->root, lower, upper);
}